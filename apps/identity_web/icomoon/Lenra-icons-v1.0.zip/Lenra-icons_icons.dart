// Place fonts/Lenra-icons.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: Lenra-icons
//      fonts:
//       - asset: fonts/Lenra-icons.ttf
import 'package:flutter/widgets.dart';

class Lenra_icons {
  Lenra_icons._();

  static const String _fontFamily = 'Lenra-icons';

  static const IconData check = IconData(0xe900, fontFamily: _fontFamily);
  static const IconData eye = IconData(0xe901, fontFamily: _fontFamily);
  static const IconData eye_off = IconData(0xe902, fontFamily: _fontFamily);
  static const IconData x = IconData(0xe940, fontFamily: _fontFamily);
  static const IconData chevron_right = IconData(0xe92c, fontFamily: _fontFamily);
  static const IconData arrow_right = IconData(0xe916, fontFamily: _fontFamily);
}
